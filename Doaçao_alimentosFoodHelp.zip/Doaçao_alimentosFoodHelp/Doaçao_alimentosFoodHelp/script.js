document.addEventListener("DOMContentLoaded", function () {
    const line = document.getElementById("line");
    const navItems = document.querySelectorAll(".nav-li");
    const activeNav = document.querySelector(".active-nav");

    if (activeNav) {
        line.style.width = activeNav.offsetWidth + "px";
        line.style.marginLeft = activeNav.offsetLeft + "px";
    }

    navItems.forEach((item) => {
        item.addEventListener("mouseenter", function () {
            line.style.width = this.offsetWidth + "px";
            line.style.marginLeft = this.offsetLeft + "px";
        });
    });

    document.querySelector("nav").addEventListener("mouseleave", function () {
        if (activeNav) {
            line.style.width = activeNav.offsetWidth + "px";
            line.style.marginLeft = activeNav.offsetLeft + "px";
        }
    });

    // Função para verificar se o usuário está logado
    function checkLogin() {
        const loggedUser = localStorage.getItem("usuarioLogado");

        const loginLink = document.getElementById("loginLink");
        const welcomeMessage = document.getElementById("welcomeMessage");

        if (loggedUser) {
            // Se o usuário está logado
            loginLink.textContent = "Sair";
            welcomeMessage.textContent = `Bem-vindo! Você está logado.`;
        } else {
            // Se o usuário não está logado
            welcomeMessage.textContent = "Faça login para cadastrar suas doações.";
            loginLink.textContent = "Entrar";
        }

        // Ação do link Entrar/Sair
        loginLink.addEventListener("click", function (event) {
            event.preventDefault();

            if (loggedUser) {
                // Realiza o logout
                localStorage.removeItem("usuarioLogado");
                window.location.href = "lg.html"; // Redireciona para login
            } else {
                window.location.href = "lg.html"; // Redireciona para login
            }
        });
    }
    

    checkLogin();
});
