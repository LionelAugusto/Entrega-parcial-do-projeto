const express = require('express');
const cors = require('cors');
const path = require('path');

const usuarioRoutes = require('./routes/usuario.routes');
const donationRoutes = require('./routes/donation.routes'); // ⬅️ Importar rotas de doações

const app = express();

app.use(cors());
app.use(express.json());

// Rotas da API
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/doacoes', donationRoutes); // ⬅️ Usar rota de doações com prefixo

// Servir página inicial
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
