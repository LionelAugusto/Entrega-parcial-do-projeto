const Usuario = require('../models/Usuario');

const registrarUsuario = async (req, res) => {
  try {
    const { nome, email, senha, tipoUsuario, documento } = req.body;

    // Verifica se o email já existe
    const usuarioExistente = await Usuario.findOne({ email });
    if (usuarioExistente) {
      return res.status(400).json({ mensagem: 'E-mail já está cadastrado' });
    }

    // Cria um novo usuário e chama o save() para ativar o middleware de hash
    const novoUsuario = new Usuario({
      nome,
      email,
      senha,
      tipoUsuario,
      documento
    });

    await novoUsuario.save(); // Isso vai disparar o hash da senha automaticamente

    res.status(201).json({ mensagem: 'Usuário registrado com sucesso' });
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ mensagem: 'Erro ao registrar usuário' });
  }
};

module.exports = {
  registrarUsuario
};
