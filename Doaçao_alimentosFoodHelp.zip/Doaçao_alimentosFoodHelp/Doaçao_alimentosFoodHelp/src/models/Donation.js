const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
  nomeItem: { type: String, required: true },
  descricao: { type: String },
  quantidade: { type: Number, required: true },
  dataExpiracao: { type: Date },
  dataCadastro: { type: Date, default: Date.now },
  estabelecimentoId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  }
});

module.exports = mongoose.model('Donation', donationSchema);
