const express = require('express');
const router = express.Router();
const Donation = require('../models/Donation');

router.post('/cadastrar', async (req, res) => {
  try {
    const { nomeItem, descricao, quantidade, dataExpiracao, estabelecimentoId } = req.body;

    const novaDoacao = new Donation({
      nomeItem,
      descricao,
      quantidade,
      dataExpiracao,
      estabelecimentoId
    });

    await novaDoacao.save();
    res.status(201).json({ mensagem: 'Doação cadastrada com sucesso!' });
  } catch (error) {
    console.error('Erro ao cadastrar doação:', error);
    res.status(500).json({ mensagem: 'Erro ao cadastrar doação.' });
  }
});

module.exports = router;
