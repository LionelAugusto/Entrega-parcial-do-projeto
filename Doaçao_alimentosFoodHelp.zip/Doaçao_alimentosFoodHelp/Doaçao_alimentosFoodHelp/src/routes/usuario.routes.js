const express = require('express');
const router = express.Router(); // <- ESSENCIAL
const Usuario = require('../models/Usuario');
const bcrypt = require('bcryptjs');

// Rota de registro
router.post('/registrar', async (req, res) => {
  try {
    const { nome, email, senha, tipoUsuario, documento } = req.body;

    const usuarioExistente = await Usuario.findOne({ email });
    if (usuarioExistente) {
      return res.status(400).json({ mensagem: 'E-mail já cadastrado.' });
    }

    const novoUsuario = new Usuario({ nome, email, senha, tipoUsuario, documento });
    await novoUsuario.save();

    res.status(201).json({ mensagem: 'Usuário cadastrado com sucesso!' });
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ mensagem: 'Erro ao registrar o usuário.' });
  }
});

// Rota de login
router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;

    const usuario = await Usuario.findOne({ email });
    if (!usuario) {
      return res.status(400).json({ mensagem: 'Usuário não encontrado' });
    }

    const senhaValida = await bcrypt.compare(senha, usuario.senha);
    if (!senhaValida) {
      return res.status(401).json({ mensagem: 'Senha incorreta' });
    }

    res.status(200).json({ mensagem: 'Login realizado com sucesso', usuario });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ mensagem: 'Erro ao realizar login' });
  }
});

module.exports = router;
