const donationRoutes = require('./src/routes/donation.routes');
app.use('/api/doacoes', donationRoutes);



const router = express.Router();
const { registrarUsuario } = require('../controllers/usuario.controller');

router.post('/api/usuarios/registrar', registrarUsuario);

module.exports = router;



const usuarioRoutes = require('./src/routes/usuario.routes');
app.use('/api/usuarios', usuarioRoutes);

require('dotenv').config();
const connectDB = require('./src/config/database');
connectDB();

const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para JSON
app.use(express.json());

// Servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Rotas da API
const usuarioRoutes = require('./src/routes/usuario.routes');
app.use('/api/usuarios', usuarioRoutes);

// Rota padrão
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});