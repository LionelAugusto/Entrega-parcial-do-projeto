const express = require('express');
const path = require('path');
const app = express();

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos da pasta public
app.use(express.static(path.join(__dirname, '../public')));

// Rota para enviar index.html na raiz
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Rota de teste
app.get('/ping', (req, res) => {
  res.send('pong');
});

// Importa e usa rotas
console.log('Carregando rotas de doacoes...');
const doacaoRoutes = require('./routes/doacao.routes');
app.use('/doacoes', doacaoRoutes);

module.exports = app;




