const Usuario = require('../models/Usuario');
const bcrypt = require('bcryptjs');

const registrarUsuario = async (req, res) => {
  try {
    const { nome, email, senha } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ mensagem: 'Preencha todos os campos.' });
    }

    const usuarioExistente = await Usuario.findOne({ email });
    if (usuarioExistente) {
      return res.status(400).json({ mensagem: 'Usuário já existe com esse e-mail.' });
    }

    // Hash da senha
    const salt = await bcrypt.genSalt(10);
    const senhaHasheada = await bcrypt.hash(senha, salt);

    const novoUsuario = new Usuario({ nome, email, senha: senhaHasheada });
    await novoUsuario.save();

    res.status(201).json({ mensagem: 'Usuário registrado com sucesso!', usuario: novoUsuario });
  } catch (error) {
    res.status(500).json({ mensagem: 'Erro ao registrar usuário.', erro: error.message });
  }
};

const loginUsuario = async (req, res) => {
  try {
    const { email, senha } = req.body;

    const usuario = await Usuario.findOne({ email });
    if (!usuario) {
      return res.status(401).json({ mensagem: 'Credenciais inválidas.' });
    }

    // Compara senha com hash
    const senhaValida = await bcrypt.compare(senha, usuario.senha);
    if (!senhaValida) {
      return res.status(401).json({ mensagem: 'Credenciais inválidas.' });
    }

    res.status(200).json({ mensagem: 'Login bem-sucedido.', usuario });
  } catch (error) {
    res.status(500).json({ mensagem: 'Erro ao fazer login.', erro: error.message });
  }
};

module.exports = {
  registrarUsuario,
  loginUsuario,
};
