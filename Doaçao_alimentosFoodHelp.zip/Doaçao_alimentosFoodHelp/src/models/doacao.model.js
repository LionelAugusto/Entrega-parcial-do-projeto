const mongoose = require('mongoose');

const doacaoSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  descricao: String,
  quantidade: { type: Number, required: true },
  dataExpiracao: Date,
  criadoPor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true,
  },
  dataCriacao: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Doacao', doacaoSchema);
