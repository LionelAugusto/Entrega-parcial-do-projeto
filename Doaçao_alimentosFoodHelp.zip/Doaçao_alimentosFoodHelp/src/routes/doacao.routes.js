const express = require('express');
const router = express.Router();
const Doacao = require('../models/doacao.model');

// Criar nova doação
router.post('/', async (req, res) => {
  try {
    const doacao = new Doacao(req.body);
    await doacao.save();
    res.status(201).json(doacao);
  } catch (err) {
    res.status(400).json({ erro: 'Erro ao criar doação', detalhes: err.message });
  }
});

// Listar todas as doações
router.get('/', async (req, res) => {
  try {
    const doacoes = await Doacao.find().populate('criadoPor', 'nome email');
    res.json(doacoes);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao buscar doações' });
  }
});

// Obter doação por ID
router.get('/:id', async (req, res) => {
  try {
    const doacao = await Doacao.findById(req.params.id).populate('criadoPor', 'nome email');
    if (!doacao) return res.status(404).json({ erro: 'Doação não encontrada' });
    res.json(doacao);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao buscar doação' });
  }
});

// Remover doação
router.delete('/:id', async (req, res) => {
  try {
    const doacao = await Doacao.findByIdAndDelete(req.params.id);
    if (!doacao) return res.status(404).json({ erro: 'Doação não encontrada' });
    res.json({ mensagem: 'Doação removida com sucesso' });
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao deletar doação' });
  }
});

module.exports = router;




