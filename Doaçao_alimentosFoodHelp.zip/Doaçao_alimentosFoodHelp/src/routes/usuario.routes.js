// src/routes/usuario.routes.js
const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuario.controller');

// Rota de teste (útil para verificar se o backend está no ar)
router.get('/teste', (req, res) => {
  res.json({ mensagem: 'API funcionando!' });
});

// Rotas reais de usuários
router.post('/registrar', usuarioController.registrarUsuario);
router.post('/login', usuarioController.loginUsuario);

module.exports = router;
